Hotfix 449095-1 should be installed on Sitecore 9.3.0 rev. 003498.

This hotfix replaces existing files, should be installed via Sitecore Update Installation Wizard.
When asked what to do, allow the Sitecore Update Installation Wizard to overwrite the existing files.

The following files will be overwritten:

- App_Config\Sitecore\Marketing.Tracking\Sitecore.Analytics.Tracking.config
- bin\Sitecore.Analytics.dll
- bin\Siteocre.Analytics.DataAccess
- bin\Sitecore.Analytics.XConnect

The hotfix adds the Analytics.ForwardedRequestHttpHeaderClientIpIndex setting, which can be used for specifying the index of client ip address in ForwardedRequestHttpHeader
<!--  ANALYTICS FORWARDED REQUEST HTTP HEADER CLIENT IP INDEX
            Specifies the index of client ip address in ForwardedRequestHttpHeader.
            Default value: "0"
-->
<setting name="Analytics.ForwardedRequestHttpHeaderClientIpIndex" value="0" />

It is recommended to remove the HeaderIpIndex from the XForwardedFor processor. So, the hotfix changes the node of Sitecore.Analytics.Pipelines.CreateVisits.XForwardedFor processor. 

Instead of
<processor type="Sitecore.Analytics.Pipelines.CreateVisits.XForwardedFor, Sitecore.Analytics">
    <!-- Deprecated. Remove HeaderIpIndex node and use Analytics.ForwardedRequestHttpHeaderClientIpIndex setting instead. -->
    <HeaderIpIndex>0</HeaderIpIndex>
</processor>

the following node is used
<processor type="Sitecore.Analytics.Pipelines.CreateVisits.XForwardedFor, Sitecore.Analytics" />