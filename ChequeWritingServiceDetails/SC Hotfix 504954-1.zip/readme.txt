Installation instructions:

For XP0/XP1 configurations only: before installing the current hotfix please make shure that the 'SC Hotfix 462012-3.zip' hotfix for 'Content Testing' component has been installed (https://sitecore.box.com/s/fg04qqojfzmzch9i4u5nhxha5gqnctof).

- Extract the 'SC Hotfix*.update' file from the 'SC Hotfix*.zip' package.
- Use the Update Installation Wizard to install the package.
- Run the SQL script CreateFilteredIndex.sql provided in the hotfix against master database.

Notes:
- Make sure the 'ContentSearch.Indexing.DisableDatabaseCaches' and 'Caching.DisableCacheSizeLimits' settings are disabled on the Indexing instance:
    <setting name="ContentSearch.Indexing.DisableDatabaseCaches" value="false"/>
    <setting name="Caching.DisableCacheSizeLimits" value="false" />

- Tune capacity of caches according to available memory and requirement regarding memory consumption

- As part of the fix for #177155 'LinkManager.GetItemUrl gets the wrong site' please add 'disableTrailingWildcard="true"' attribute to the site configuration under <sites> node for every site involved in the issue.

- Add the following setting to the Sitecore configuration:
    <setting name="ContentSearch.IndexingManager.DisplayShortStatistic" value="true" />
  It will eliminate requests to Solr which don't go through a load balancer. When the setting is enabled, the Indexing Manager Wizard will display only short statistic for indexes. 

- Only if you don't want to limit the usage of sitecore cache during loading translation logic, add the following setting to the Sitecore configuration:
    <setting name="Translation.LimitSitecoreCacheUsage" value="false" />
  It will keep all visited translation items inside Sitecore caches 
  
  Default value: True
  It will add visited translation items to Sitecore cache and once done processing it, it will remove it from sitecore cahce
