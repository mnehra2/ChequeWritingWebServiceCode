Installation instructions
-------------------------
This hotfix packages contain fixes to the Sitecore.CMS.Core and Sitecore.ContentTesting components. 

Please deploy these hotfixes to all instances.
1. Install 'SC Hotfix 462012-3.zip'
2. Install 'SC Hotfix 504954-1.zip' hotfix (or a later cumulative hotfix): 
https://sitecore.box.com/s/iy8hjljtttahlv12j7bcvtgwr0v8v5eg

Installation steps:
- Extract 'SC Hotfix *.zip' into a new folder
- Install the 'SC Hotfix *.update' package by navigating to Control Panel > ADMINISTRATION > Install an update
- Confirm override to the assemblies whenever prompted after performing backup
