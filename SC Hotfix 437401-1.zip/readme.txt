This package contains updates to the Email Experience Management component, specifically to the Sitecore.EmailCampaign.Cm.dll, Sitecore.EmailCampaign.XConnect.Web.dll, Sitecore.ExM.Framework.dll assemblies.

To deploy this hotfix:
 
- Extract the 'SC Hotfix 437401-1.zip' file to the '[data folder]\packages' folder on the CMS server.
- Use the Package Installation Wizard within the CMS to install the package.
- If prompted, allow the Installation Wizard to overwrite the existing files.